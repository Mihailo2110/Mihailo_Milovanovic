echo '------- Build compose -------'
docker-compose up --build -d
